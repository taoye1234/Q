//#include <cstdint>
//#include <iostream>
#include<stdio.h>

typedef struct
{
	int get_count;
	int set_count;
	float out;
}ramp_t;
void ramp_init(ramp_t *ramp,int target_count)
{
	ramp->get_count = 0;
	ramp->set_count = target_count;
	ramp->out = 0;
}
float ramp_calc(ramp_t *ramp)
{
	if(ramp->set_count <= 0)
	return 0;
	if(ramp->get_count >= ramp->set_count)
	ramp->get_count = ramp->set_count;
	else
	ramp->get_count++;
	ramp->out = (float)ramp->get_count/(float)ramp->set_count;
	return ramp->out;
}

int main()
{
 int x;
 int y;
 x=10;
 y=10;





















 return 0;
}












 
