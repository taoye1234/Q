
#include<stdio.h>
#include<string.h>


int main()
{

	uint8_t alpha = 0;
    uint8_t beta = 0;
	
	int x=0;
	int gama = 20001;
	int *p=&gama;
	uint8_t alpha = *p-8;
	uint8_t beta = *p+8
	
	return 0;
}
