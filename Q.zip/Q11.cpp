int,short,long,long long,char,float,double,struct,enum,union
