#include <stdio.h>
#include <math.h>

#define PI 3.141592653
#define BIG_SIZE 10 

void buffer(float *a, float b, float high_parameter, float low_parameter)
{
	int x;
	
	if (((*a - b) <= high_parameter) && ((*a - b) >= -low_parameter))
	{
	*a = b; 
	
		for (*a= 1; *a < b; *a++) {
          	  printf("\n");//��ӡ*֮ǰ�Ŀո�
        	}
        	printf("*");
	}
	else
	{
	if (*a < b)
	*a += high_parameter;
	for (*a= 1; *a < b; *a++) {
            printf("\n");//��ӡ*֮ǰ�Ŀո�
        }
        printf("*");
	if (*a > b)
	*a -= low_parameter;
	for (*a= 1; *a < b; *a++) {
            printf("\n");//��ӡ*֮ǰ�Ŀո�
        }
        printf("*");
	}
}



int main() {
    int x;//x��
    double y;//y��
float now1 = 50.5 ;
float now2 = -30.3 ;
float ref1 = 100.1;
float ref2 = -70.7;
float high = 1.0 ;
float low = 1.0 ;

buffer (&now1,ref1,high,low);
buffer (&now2,ref2,high,low);
}





