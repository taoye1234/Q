
#include<stdio.h>
#include<string.h>
float HAL_GetTick(void)
{
 float uwTick;
 return uwTick;
}

int main()
{
	float HAL_GetTick(void);
	while (1){
	
	if (uwTick% ==0)
	{
		printf("Hellow World");
		
	}
	} 
	
	return 0;
}
